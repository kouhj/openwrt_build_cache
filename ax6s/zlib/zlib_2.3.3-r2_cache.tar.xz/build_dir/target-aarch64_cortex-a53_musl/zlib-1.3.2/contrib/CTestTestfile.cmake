# CMake generated Testfile for 
# Source directory: /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-aarch64_cortex-a53_musl/zlib-1.3.2/contrib
# Build directory: /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-aarch64_cortex-a53_musl/zlib-1.3.2/contrib
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
