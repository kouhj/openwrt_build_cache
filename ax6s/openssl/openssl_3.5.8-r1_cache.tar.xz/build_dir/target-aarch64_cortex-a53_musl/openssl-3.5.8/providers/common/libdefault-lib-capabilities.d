providers/common/libdefault-lib-capabilities.o: \
 providers/common/capabilities.c \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/core_dispatch.h include/openssl/core.h \
 include/openssl/types.h include/openssl/e_os2.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/openssl/core_names.h include/openssl/prov_ssl.h \
 include/internal/nelem.h include/internal/tlsgroups.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h include/internal/e_os.h \
 include/internal/numbers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/unistd.h \
 include/crypto/ml_kem.h include/openssl/bio.h include/openssl/bioerr.h \
 include/crypto/evp.h include/openssl/evp.h include/openssl/evperr.h \
 include/openssl/objects.h include/openssl/obj_mac.h \
 include/openssl/asn1.h include/openssl/asn1err.h \
 include/openssl/objectserr.h include/internal/refcount.h \
 include/openssl/trace.h include/openssl/err.h include/openssl/lhash.h \
 include/crypto/ecx.h include/crypto/types.h
