providers/common/der/libcommon-lib-der_slh_dsa_gen.o: \
 providers/common/der/der_slh_dsa_gen.c \
 providers/common/include/prov/der_slh_dsa.h include/internal/der.h \
 include/openssl/bn.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/e_os2.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/core.h \
 include/openssl/bnerr.h include/internal/packet.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/buffer.h include/openssl/buffererr.h \
 include/internal/numbers.h include/crypto/slh_dsa.h \
 include/crypto/types.h
