providers/implementations/keymgmt/libdefault-lib-dh_kmgmt.o: \
 providers/implementations/keymgmt/dh_kmgmt.c \
 include/internal/deprecated.h include/openssl/configuration.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/opensslv.h include/internal/common.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/internal/e_os.h include/openssl/e_os2.h include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/safestack.h include/openssl/stack.h \
 include/openssl/types.h include/openssl/cryptoerr.h \
 include/openssl/symhacks.h include/openssl/cryptoerr_legacy.h \
 include/openssl/core.h include/internal/numbers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/unistd.h \
 include/internal/nelem.h include/openssl/core_dispatch.h \
 include/openssl/indicator.h include/openssl/params.h \
 include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/core_names.h include/openssl/err.h include/openssl/bio.h \
 include/openssl/bioerr.h include/openssl/lhash.h \
 include/openssl/self_test.h \
 providers/implementations/include/prov/implementations.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h providers/common/include/prov/provider_ctx.h \
 include/crypto/dh.h include/openssl/dh.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/dherr.h include/internal/ffc.h \
 include/openssl/evp.h include/openssl/evperr.h include/openssl/objects.h \
 include/openssl/obj_mac.h include/openssl/objectserr.h \
 include/openssl/param_build.h include/internal/sizes.h \
 include/internal/fips.h
