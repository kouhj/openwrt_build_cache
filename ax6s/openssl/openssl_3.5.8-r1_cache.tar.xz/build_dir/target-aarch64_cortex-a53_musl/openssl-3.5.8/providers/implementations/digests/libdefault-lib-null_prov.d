providers/implementations/digests/libdefault-lib-null_prov.o: \
 providers/implementations/digests/null_prov.c include/openssl/crypto.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/configuration.h include/openssl/opensslv.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/e_os2.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/safestack.h include/openssl/stack.h \
 include/openssl/types.h include/openssl/cryptoerr.h \
 include/openssl/symhacks.h include/openssl/cryptoerr_legacy.h \
 include/openssl/core.h \
 providers/implementations/include/prov/digestcommon.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/core_names.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h \
 providers/implementations/include/prov/implementations.h
