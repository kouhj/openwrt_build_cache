providers/implementations/skeymgmt/libdefault-lib-aes_skmgmt.o: \
 providers/implementations/skeymgmt/aes_skmgmt.c \
 include/openssl/core_dispatch.h include/openssl/core.h \
 include/openssl/types.h include/openssl/e_os2.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/crypto/types.h providers/implementations/skeymgmt/skeymgmt_lcl.h \
 include/internal/skey.h \
 providers/implementations/include/prov/implementations.h
