providers/implementations/signature/libdefault-lib-ml_dsa_sig.o: \
 providers/implementations/signature/ml_dsa_sig.c \
 include/internal/deprecated.h include/openssl/configuration.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/opensslv.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/core_names.h include/openssl/err.h \
 include/openssl/e_os2.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/bio.h include/openssl/crypto.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/core.h \
 include/openssl/bioerr.h include/openssl/lhash.h include/openssl/rand.h \
 include/openssl/randerr.h include/openssl/evp.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/evperr.h include/openssl/objects.h \
 include/openssl/obj_mac.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/objectserr.h \
 include/openssl/proverr.h \
 providers/implementations/include/prov/implementations.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h providers/common/include/prov/provider_ctx.h \
 providers/common/include/prov/der_ml_dsa.h include/internal/der.h \
 include/internal/packet.h include/openssl/buffer.h \
 include/openssl/buffererr.h include/internal/numbers.h \
 include/crypto/ml_dsa.h include/crypto/types.h include/internal/sizes.h
