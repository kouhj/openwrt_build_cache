providers/implementations/keymgmt/libdefault-lib-ml_kem_kmgmt.o: \
 providers/implementations/keymgmt/ml_kem_kmgmt.c \
 include/openssl/core_dispatch.h include/openssl/core.h \
 include/openssl/types.h include/openssl/e_os2.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/openssl/core_names.h include/openssl/err.h include/openssl/bio.h \
 include/openssl/bioerr.h include/openssl/lhash.h \
 include/openssl/proverr.h include/openssl/provider.h \
 include/openssl/rand.h include/openssl/randerr.h include/openssl/evp.h \
 include/openssl/evperr.h include/openssl/objects.h \
 include/openssl/obj_mac.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/objectserr.h \
 include/openssl/self_test.h include/openssl/param_build.h \
 include/crypto/ml_kem.h include/crypto/evp.h include/internal/refcount.h \
 include/openssl/trace.h include/crypto/ecx.h include/crypto/types.h \
 include/internal/fips.h include/internal/param_build_set.h \
 include/internal/cryptlib.h include/internal/common.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/internal/e_os.h include/internal/numbers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/unistd.h \
 include/internal/nelem.h include/openssl/buffer.h \
 include/openssl/buffererr.h \
 providers/implementations/include/prov/implementations.h \
 providers/common/include/prov/providercommon.h \
 providers/common/include/prov/provider_ctx.h \
 providers/common/include/prov/securitycheck.h include/openssl/ec.h \
 include/openssl/ecerr.h providers/fips/include/fips/fipsindicator.h \
 providers/implementations/include/prov/ml_kem.h
