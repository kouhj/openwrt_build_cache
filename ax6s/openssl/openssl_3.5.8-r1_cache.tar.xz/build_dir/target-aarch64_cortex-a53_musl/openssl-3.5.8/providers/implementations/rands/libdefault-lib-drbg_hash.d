providers/implementations/rands/libdefault-lib-drbg_hash.o: \
 providers/implementations/rands/drbg_hash.c \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/sha.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/e_os2.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/safestack.h include/openssl/stack.h \
 include/openssl/types.h include/openssl/cryptoerr.h \
 include/openssl/symhacks.h include/openssl/cryptoerr_legacy.h \
 include/openssl/core.h include/openssl/err.h include/openssl/bio.h \
 include/openssl/bioerr.h include/openssl/lhash.h include/openssl/rand.h \
 include/openssl/randerr.h include/openssl/evp.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/evperr.h include/openssl/objects.h \
 include/openssl/obj_mac.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/objectserr.h \
 include/openssl/proverr.h include/internal/thread_once.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h providers/common/include/prov/provider_ctx.h \
 providers/common/include/prov/provider_util.h \
 providers/implementations/include/prov/implementations.h \
 providers/implementations/rands/drbg_local.h \
 include/openssl/core_names.h include/internal/tsan_assist.h \
 include/internal/nelem.h include/internal/numbers.h \
 providers/common/include/prov/securitycheck.h include/crypto/types.h \
 include/openssl/ec.h include/openssl/ecerr.h \
 providers/fips/include/fips/fipsindicator.h include/crypto/evp.h \
 include/internal/refcount.h include/openssl/trace.h include/crypto/ecx.h \
 crypto/evp/evp_local.h include/internal/provider.h \
 include/internal/dso.h include/internal/dsoerr.h \
 include/internal/symhacks.h
