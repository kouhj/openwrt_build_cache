providers/implementations/kdfs/libdefault-lib-argon2.o: \
 providers/implementations/kdfs/argon2.c \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/e_os2.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/evp.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/core.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h include/openssl/crypto.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/openssl/bio.h include/openssl/bioerr.h include/openssl/evperr.h \
 include/openssl/objects.h include/openssl/obj_mac.h \
 include/openssl/asn1.h include/openssl/asn1err.h \
 include/openssl/objectserr.h include/openssl/kdf.h include/openssl/err.h \
 include/openssl/lhash.h include/openssl/core_names.h \
 include/openssl/thread.h include/openssl/proverr.h \
 include/internal/thread.h include/internal/thread_arch.h \
 include/internal/time.h include/internal/e_os.h \
 include/internal/numbers.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/unistd.h \
 include/internal/e_winsock.h include/internal/safe_math.h \
 include/internal/cryptlib.h include/internal/common.h \
 include/internal/nelem.h include/openssl/buffer.h \
 include/openssl/buffererr.h include/crypto/context.h \
 include/internal/endian.h include/crypto/evp.h \
 include/internal/refcount.h include/openssl/trace.h include/crypto/ecx.h \
 include/crypto/types.h \
 providers/implementations/include/prov/implementations.h \
 providers/common/include/prov/provider_ctx.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h \
 providers/implementations/include/prov/blake2.h
