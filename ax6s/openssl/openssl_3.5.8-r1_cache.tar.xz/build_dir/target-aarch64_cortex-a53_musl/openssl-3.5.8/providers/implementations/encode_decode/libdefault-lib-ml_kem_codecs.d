providers/implementations/encode_decode/libdefault-lib-ml_kem_codecs.o: \
 providers/implementations/encode_decode/ml_kem_codecs.c \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/byteorder.h include/openssl/e_os2.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/configuration.h include/openssl/opensslv.h \
 include/openssl/proverr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/x509.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/buffer.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdlib.h \
 /home/builder/kbuilder/ax6s/sdk/openwrt-sdk-25.12.6-mediatek-mt7622_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-aarch64_cortex-a53_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/cryptoerr.h include/openssl/core.h \
 include/openssl/buffererr.h include/openssl/evp.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/bio.h include/openssl/bioerr.h include/openssl/evperr.h \
 include/openssl/objects.h include/openssl/obj_mac.h \
 include/openssl/asn1.h include/openssl/asn1err.h \
 include/openssl/objectserr.h include/openssl/ec.h \
 include/openssl/ecerr.h include/openssl/rsa.h include/openssl/rsaerr.h \
 include/openssl/dsa.h include/openssl/dh.h include/openssl/dherr.h \
 include/openssl/dsaerr.h include/openssl/sha.h include/openssl/x509err.h \
 include/openssl/x509_vfy.h include/openssl/lhash.h \
 include/openssl/pkcs7.h include/openssl/pkcs7err.h \
 include/openssl/http.h include/openssl/conf.h include/openssl/conferr.h \
 include/openssl/conftypes.h include/openssl/core_names.h \
 include/internal/encoder.h include/internal/ffc.h \
 include/openssl/param_build.h include/internal/sizes.h \
 providers/implementations/include/prov/ml_kem.h include/crypto/ml_kem.h \
 include/crypto/evp.h include/internal/refcount.h include/openssl/trace.h \
 include/openssl/err.h include/crypto/ecx.h include/crypto/types.h \
 providers/common/include/prov/provider_ctx.h \
 providers/implementations/encode_decode/ml_kem_codecs.h \
 providers/implementations/encode_decode/ml_common_codecs.h \
 include/crypto/ml_dsa.h
