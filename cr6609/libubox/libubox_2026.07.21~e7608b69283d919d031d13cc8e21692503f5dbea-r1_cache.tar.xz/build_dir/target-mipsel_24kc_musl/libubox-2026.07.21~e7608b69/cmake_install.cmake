# Install script for directory: /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "TRUE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/bin/mipsel-openwrt-linux-musl-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/libubox" TYPE FILE FILES
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/assert.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/avl-cmp.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/avl.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/blob.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/blobmsg.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/blobmsg_json.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/json_script.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/kvlist.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/list.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/md5.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/runqueue.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/safe_list.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/udebug-proto.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/udebug.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/ulog.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/uloop.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/usock.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/ustream.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/utils.h"
    "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/vlist.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libubox.so.20260721")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libubox.so.20260721" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libubox.so.20260721")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/:" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libubox.so.20260721")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libubox.so")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libubox.a")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libblobmsg_json.so.20260721")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libblobmsg_json.so.20260721" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libblobmsg_json.so.20260721")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/:" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libblobmsg_json.so.20260721")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libblobmsg_json.so")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libblobmsg_json.a")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/jshn")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/jshn" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/jshn")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/:" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/jshn")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libjson_script.so.20260721")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libjson_script.so.20260721" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libjson_script.so.20260721")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/:" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libjson_script.so.20260721")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/libjson_script.so")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/libubox" TYPE FILE FILES "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/sh/jshn.sh")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for each subdirectory.
  include("/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/lua/cmake_install.cmake")
  include("/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/examples/cmake_install.cmake")

endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-mipsel_24kc_musl/libubox-2026.07.21~e7608b69/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
