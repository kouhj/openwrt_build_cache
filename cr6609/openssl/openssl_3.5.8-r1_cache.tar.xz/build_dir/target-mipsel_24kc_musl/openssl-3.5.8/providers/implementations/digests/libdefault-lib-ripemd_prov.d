providers/implementations/digests/libdefault-lib-ripemd_prov.o: \
 providers/implementations/digests/ripemd_prov.c \
 include/internal/deprecated.h include/openssl/configuration.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/opensslv.h include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/e_os2.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/safestack.h include/openssl/stack.h \
 include/openssl/types.h include/openssl/cryptoerr.h \
 include/openssl/symhacks.h include/openssl/cryptoerr_legacy.h \
 include/openssl/core.h include/openssl/ripemd.h \
 providers/implementations/include/prov/digestcommon.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/core_names.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h \
 providers/implementations/include/prov/implementations.h
