providers/implementations/encode_decode/libdefault-lib-decode_der2key.o: \
 providers/implementations/encode_decode/decode_der2key.c \
 include/internal/deprecated.h include/openssl/configuration.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/opensslv.h include/openssl/byteorder.h \
 include/openssl/e_os2.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/core_dispatch.h include/openssl/core.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/indicator.h \
 include/openssl/params.h include/openssl/bn.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/openssl/core_names.h include/openssl/core_object.h \
 include/openssl/err.h include/openssl/bio.h include/openssl/bioerr.h \
 include/openssl/lhash.h include/openssl/pem.h include/openssl/evp.h \
 include/openssl/evperr.h include/openssl/objects.h \
 include/openssl/obj_mac.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/objectserr.h \
 include/openssl/x509.h include/openssl/buffer.h \
 include/openssl/buffererr.h include/openssl/ec.h include/openssl/ecerr.h \
 include/openssl/rsa.h include/openssl/rsaerr.h include/openssl/dsa.h \
 include/openssl/dh.h include/openssl/dherr.h include/openssl/dsaerr.h \
 include/openssl/sha.h include/openssl/x509err.h \
 include/openssl/x509_vfy.h include/openssl/pkcs7.h \
 include/openssl/pkcs7err.h include/openssl/http.h include/openssl/conf.h \
 include/openssl/conferr.h include/openssl/conftypes.h \
 include/openssl/pemerr.h include/openssl/pkcs12.h \
 include/openssl/pkcs12err.h include/openssl/provider.h \
 include/openssl/proverr.h include/openssl/asn1t.h \
 include/internal/cryptlib.h include/internal/common.h \
 include/internal/e_os.h include/internal/numbers.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/unistd.h \
 include/internal/nelem.h include/crypto/dh.h include/internal/ffc.h \
 include/openssl/param_build.h include/internal/sizes.h \
 include/crypto/dsa.h include/crypto/ec.h include/crypto/types.h \
 include/crypto/evp.h include/internal/refcount.h include/openssl/trace.h \
 include/crypto/ecx.h include/crypto/rsa.h include/crypto/ml_dsa.h \
 include/crypto/slh_dsa.h include/crypto/x509.h include/crypto/ml_kem.h \
 providers/common/include/prov/bio.h \
 providers/common/include/prov/provider_ctx.h \
 providers/implementations/include/prov/implementations.h \
 providers/implementations/encode_decode/endecoder_local.h \
 providers/implementations/encode_decode/ml_dsa_codecs.h \
 providers/implementations/encode_decode/ml_common_codecs.h \
 providers/implementations/encode_decode/ml_kem_codecs.h
