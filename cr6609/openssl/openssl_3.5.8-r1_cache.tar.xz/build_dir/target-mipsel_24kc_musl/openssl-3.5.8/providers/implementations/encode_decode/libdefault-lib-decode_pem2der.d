providers/implementations/encode_decode/libdefault-lib-decode_pem2der.o: \
 providers/implementations/encode_decode/decode_pem2der.c \
 include/internal/deprecated.h include/openssl/configuration.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/opensslv.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/core_dispatch.h include/openssl/core.h \
 include/openssl/types.h include/openssl/e_os2.h \
 include/openssl/safestack.h include/openssl/stack.h \
 include/openssl/indicator.h include/openssl/params.h \
 include/openssl/bn.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/openssl/core_names.h include/openssl/core_object.h \
 include/openssl/err.h include/openssl/bio.h include/openssl/bioerr.h \
 include/openssl/lhash.h include/openssl/pem.h include/openssl/evp.h \
 include/openssl/evperr.h include/openssl/objects.h \
 include/openssl/obj_mac.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/objectserr.h \
 include/openssl/x509.h include/openssl/buffer.h \
 include/openssl/buffererr.h include/openssl/ec.h include/openssl/ecerr.h \
 include/openssl/rsa.h include/openssl/rsaerr.h include/openssl/dsa.h \
 include/openssl/dh.h include/openssl/dherr.h include/openssl/dsaerr.h \
 include/openssl/sha.h include/openssl/x509err.h \
 include/openssl/x509_vfy.h include/openssl/pkcs7.h \
 include/openssl/pkcs7err.h include/openssl/http.h include/openssl/conf.h \
 include/openssl/conferr.h include/openssl/conftypes.h \
 include/openssl/pemerr.h include/openssl/proverr.h \
 include/internal/nelem.h include/internal/sizes.h \
 providers/common/include/prov/bio.h \
 providers/common/include/prov/provider_ctx.h \
 providers/implementations/include/prov/decoders.h \
 providers/implementations/include/prov/implementations.h \
 providers/implementations/encode_decode/endecoder_local.h
