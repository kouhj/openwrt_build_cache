providers/implementations/ciphers/liblegacy-lib-cipher_rc4.o: \
 providers/implementations/ciphers/cipher_rc4.c \
 include/internal/deprecated.h include/openssl/configuration.h \
 include/openssl/macros.h include/openssl/opensslconf.h \
 include/openssl/opensslv.h \
 providers/implementations/ciphers/cipher_rc4.h include/openssl/rc4.h \
 providers/implementations/include/prov/ciphercommon.h \
 include/openssl/params.h include/openssl/core.h include/openssl/types.h \
 include/openssl/e_os2.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/bn.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/bnerr.h \
 include/openssl/core_dispatch.h include/openssl/indicator.h \
 include/openssl/core_names.h include/openssl/evp.h include/openssl/bio.h \
 include/openssl/bioerr.h include/openssl/evperr.h \
 include/openssl/objects.h include/openssl/obj_mac.h \
 include/openssl/asn1.h include/openssl/asn1err.h \
 include/openssl/objectserr.h include/internal/cryptlib.h \
 include/internal/common.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/string.h \
 include/internal/e_os.h include/internal/numbers.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/unistd.h \
 include/internal/nelem.h include/openssl/buffer.h \
 include/openssl/buffererr.h include/openssl/err.h \
 include/openssl/lhash.h include/crypto/modes.h include/openssl/modes.h \
 providers/implementations/include/prov/implementations.h \
 providers/common/include/prov/providercommon.h \
 include/openssl/provider.h
