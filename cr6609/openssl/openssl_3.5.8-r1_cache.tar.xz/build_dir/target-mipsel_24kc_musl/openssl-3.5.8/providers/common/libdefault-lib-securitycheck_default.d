providers/common/libdefault-lib-securitycheck_default.o: \
 providers/common/securitycheck_default.c include/internal/deprecated.h \
 include/openssl/configuration.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/opensslv.h \
 include/openssl/rsa.h include/openssl/asn1.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/e_os2.h include/openssl/bio.h include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/safestack.h include/openssl/stack.h \
 include/openssl/types.h include/openssl/cryptoerr.h \
 include/openssl/symhacks.h include/openssl/cryptoerr_legacy.h \
 include/openssl/core.h include/openssl/bioerr.h \
 include/openssl/asn1err.h include/openssl/bn.h include/openssl/bnerr.h \
 include/openssl/rsaerr.h include/openssl/core_names.h \
 include/openssl/obj_mac.h providers/common/include/prov/securitycheck.h \
 include/crypto/types.h include/openssl/ec.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/ecerr.h include/openssl/params.h \
 providers/fips/include/fips/fipsindicator.h include/internal/nelem.h
