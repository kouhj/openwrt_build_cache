providers/common/der/libcommon-lib-der_dsa_gen.o: \
 providers/common/der/der_dsa_gen.c include/internal/deprecated.h \
 include/openssl/configuration.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/opensslv.h \
 providers/common/include/prov/der_dsa.h include/internal/der.h \
 include/openssl/bn.h include/openssl/e_os2.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/fortify-headers.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/core.h \
 include/openssl/bnerr.h include/internal/packet.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/buffer.h include/openssl/buffererr.h \
 include/internal/numbers.h
