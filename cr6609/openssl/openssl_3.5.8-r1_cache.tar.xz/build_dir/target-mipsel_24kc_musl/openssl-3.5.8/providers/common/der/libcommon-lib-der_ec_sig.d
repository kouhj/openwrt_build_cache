providers/common/der/libcommon-lib-der_ec_sig.o: \
 providers/common/der/der_ec_sig.c include/openssl/obj_mac.h \
 include/internal/packet.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/string.h \
 include/openssl/bn.h include/openssl/macros.h \
 include/openssl/opensslconf.h include/openssl/configuration.h \
 include/openssl/opensslv.h include/openssl/e_os2.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdio.h \
 include/openssl/types.h include/openssl/safestack.h \
 include/openssl/stack.h include/openssl/crypto.h \
 /home/builder/kbuilder/cr6609/sdk/openwrt-sdk-25.12.6-ramips-mt7621_gcc-14.3.0_musl.Linux-x86_64/staging_dir/toolchain-mipsel_24kc_gcc-14.3.0_musl/include/fortify/stdlib.h \
 include/openssl/cryptoerr.h include/openssl/symhacks.h \
 include/openssl/cryptoerr_legacy.h include/openssl/core.h \
 include/openssl/bnerr.h include/openssl/buffer.h \
 include/openssl/buffererr.h include/internal/numbers.h \
 providers/common/include/prov/der_ec.h include/crypto/ec.h \
 include/openssl/evp.h include/openssl/core_dispatch.h \
 include/openssl/indicator.h include/openssl/params.h \
 include/openssl/bio.h include/openssl/bioerr.h include/openssl/evperr.h \
 include/openssl/objects.h include/openssl/asn1.h \
 include/openssl/asn1err.h include/openssl/objectserr.h \
 include/openssl/ec.h include/openssl/ecerr.h include/crypto/types.h \
 include/internal/der.h
