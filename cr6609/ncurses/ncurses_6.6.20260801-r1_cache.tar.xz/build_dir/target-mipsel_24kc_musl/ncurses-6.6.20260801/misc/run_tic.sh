#!/bin/sh
# $Id: run_tic.in,v 1.44 2025/09/13 16:52:46 tom Exp $
##############################################################################
# Copyright 2019-2024,2025 Thomas E. Dickey                                  #
# Copyright 2000-2012,2017 Free Software Foundation, Inc.                    #
#                                                                            #
# Permission is hereby granted, free of charge, to any person obtaining a    #
# copy of this software and associated documentation files (the "Software"), #
# to deal in the Software without restriction, including without limitation  #
# the rights to use, copy, modify, merge, publish, distribute, distribute    #
# with modifications, sublicense, and/or sell copies of the Software, and to #
# permit persons to whom the Software is furnished to do so, subject to the  #
# following conditions:                                                      #
#                                                                            #
# The above copyright notice and this permission notice shall be included in #
# all copies or substantial portions of the Software.                        #
#                                                                            #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR #
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,   #
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL    #
# THE ABOVE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      #
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING    #
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER        #
# DEALINGS IN THE SOFTWARE.                                                  #
#                                                                            #
# Except as contained in this notice, the name(s) of the above copyright     #
# holders shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written               #
# authorization.                                                             #
##############################################################################
#
# Author: Thomas E. Dickey 1996-on
#
# This script is used to install terminfo.src using tic.  We use a script
# because the path checking is too awkward to do in a makefile.
#
# Assumes:
#	The leaf directory names (lib, tabset, terminfo)
#
echo "** Building terminfo database, please wait..."
#
# The script is designed to be run from the misc/Makefile as
#	make install.data

# Symbols which are not overridden by misc/Makefile:
: "${prefix:=/usr}"
: "${exec_prefix:=/usr}"
: "${top_srcdir:=..}"
: "${srcdir:=.}"
: "${datarootdir:=${prefix}/share}"
: "${datadir:=/usr/share}"
: "${cross_compiling:=yes}"
: "${suffix:=}"

: "${ext_funcs:=1}"
: "${tic_path:=tic}"
: "${ticdir:=/usr/share/terminfo}"
: "${tic_source:=${top_srcdir}/misc/terminfo.src}"

# Symbols which $DESTDIR and/or install-prefix may affect:
: "${INSTALL_PREFIX:=$prefix}"
: "${BINDIR:=/usr/bin}"
: "${TICDIR:=$ticdir}"

failed() {
	echo "? $*" >&2
	exit 1
}

unset CDPATH

# Allow tic to run either from the install-path, or from the build-directory.
# Do not do this if we appear to be cross-compiling.  In that case, we rely
# on the host's copy of tic to compile the terminfo database.
if test "$cross_compiling" = "no"
then
	if test -f ../progs/tic"$suffix"
	then
		case "$PATH" in
		\:*)
			PATH="../progs:../lib:${BINDIR}$PATH"
			;;
		*)
			PATH="../progs:../lib:${BINDIR}:$PATH"
			;;
		esac
		export PATH
		if test shared = shared
		then
			SHLIB="sh $srcdir/shlib"
			tic_path="$SHLIB tic"
		else
			tic_path="tic"
		fi
	elif test "$tic_path" = unknown
	then
		failed "no tic program found"
	fi
else
	# Cross-compiling, so don't set PATH or run shlib.
	SHLIB=
	# reset $suffix, since it applies to the target, not the build platform.
	suffix=
fi


# Set another env var that doesn't get reset when `shlib' runs, so `shlib' uses
# the PATH we just set.
SHLIB_PATH=$PATH
export SHLIB_PATH

# Set a variable to simplify environment update in the shlib script.
SHLIB_HOST=linux-gnu
export SHLIB_HOST

# Don't use user's TERMINFO or TERMINFO_DIRS variables.  The explicit "-o"
# option makes this moot, but this may reduce confusion.
unset TERMINFO_DIRS
unset TERMINFO
umask 022

# Construct the name of the old (obsolete) pathname, e.g., /usr/lib/terminfo.
OLD_DIR=`echo "$TICDIR" | sed -e 's%/share/\([^/]*\)$%/lib/\1%'`

# Parent directory may not exist, which would confuse the install for hashed
# database.  Fix.
PARENT=`echo "$TICDIR" | sed -e 's%/[^/]*$%%'`
if test -n "$PARENT"
then
	mkdir -p "$PARENT"
fi

# Remove the old terminfo stuff; we don't care if it existed before, and it
# would generate a lot of confusing error messages if we tried to overwrite it.
# We explicitly remove its contents rather than the directory itself, in case
# the directory is actually a symbolic link.
if test -d "$TICDIR"
then
	test -w "$TICDIR" || failed "existing $TICDIR is not writable"
	( cd "$TICDIR" && rm -fr ./? 2>/dev/null )
elif test -f "$TICDIR.db"
then
	( rm -f "$TICDIR.db" 2>/dev/null )
	test -f "$TICDIR.db" && failed "cannot remove $TICDIR.db"
fi

if test "$ext_funcs" = 1 ; then
cat <<EOF
Running $tic_path to install $TICDIR ...

	You may see messages regarding extended capabilities, e.g., AX.
	These are extended terminal capabilities which are compiled
	using
		$tic_path -x
	If you have ncurses 4.2 applications, you should read the INSTALL
	document, and install the terminfo without the -x option.

EOF
$tic_path -V
if ( $tic_path -x -s -o "$TICDIR" "$tic_source" )
then
	echo "** built new $TICDIR"
else
	failed "$tic_path could not build $TICDIR"
fi
else
cat <<EOF
Running $tic_path to install $TICDIR ...

	You may see messages regarding unknown capabilities, e.g., AX.
	These are extended terminal capabilities which may be compiled
	using
		$tic_path -x
	If you have ncurses 4.2 applications, you should read the INSTALL
	document, and install the terminfo without the -x option.

EOF
$tic_path -V
if ( $tic_path -s -o "$TICDIR" "$tic_source" )
then
	echo "** built new $TICDIR"
else
	failed "$tic_path could not build $TICDIR"
fi
fi

# Check if we are using symbolic links, or just pretending.
case "ln -s -f" in
cp\ *)
	OLD_DIR="$TICDIR"
	echo "** assuming we cannot make symbolic links to a directory"
	;;
*)
	echo "** assuming we can make symbolic links to a directory"
	;;
esac


# Make a symbolic link to provide compatibility with applications that expect
# to find terminfo under /usr/lib.  That is, we'll _try_ to do that.  Not
# all systems support symbolic links, and those that do provide a variety
# of options for 'test'.
if test "$OLD_DIR" != "$TICDIR" ; then
	( rm -f "$OLD_DIR" 2>/dev/null )
	if ( cd "$OLD_DIR" 2>/dev/null )
	then
		cd "$OLD_DIR" || exit
		OLD_DIR=`pwd`
		if test "$OLD_DIR " != "$TICDIR "; then
			# Well, we tried.  Some systems lie to us, so the
			# installer will have to double-check.
			echo "Verify if $OLD_DIR and $TICDIR are the same."
			echo "The new terminfo is in $TICDIR; the other should be a link to it."
			echo "Otherwise, remove $OLD_DIR and link it to $TICDIR."
		fi
	else
		cd "${INSTALL_PREFIX}" || exit
		# Construct a symbolic link that only assumes $ticdir has the
		# same $prefix as the other installed directories.
		SOURCE=`echo "$ticdir"|sed -e 's%^'"$prefix"'/%%'`
		if test "$SOURCE" != "$ticdir" ; then
			SOURCE=../`echo "$ticdir"|sed -e 's%^'"$prefix"'/%%' -e 's%^/%%'`
		fi
		test -d lib || mkdir lib
		cd lib || exit
		TARGET=`pwd`/terminfo
		if ( ln -s -f "$SOURCE" terminfo )
		then
			echo "** sym-linked $TARGET for compatibility"
		else
			echo "** could not sym-link $TARGET for compatibility"
		fi
	fi
fi
# vile:shmode ts=4 sw=4
