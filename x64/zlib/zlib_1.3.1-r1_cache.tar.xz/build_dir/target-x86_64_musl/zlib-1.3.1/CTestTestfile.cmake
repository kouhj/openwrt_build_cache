# CMake generated Testfile for 
# Source directory: /home/builder/kbuilder/x64/sdk/openwrt-sdk-25.12.6-x86-64_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-x86_64_musl/zlib-1.3.1
# Build directory: /home/builder/kbuilder/x64/sdk/openwrt-sdk-25.12.6-x86-64_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-x86_64_musl/zlib-1.3.1
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(example "example")
set_tests_properties(example PROPERTIES  _BACKTRACE_TRIPLES "/home/builder/kbuilder/x64/sdk/openwrt-sdk-25.12.6-x86-64_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-x86_64_musl/zlib-1.3.1/CMakeLists.txt;236;add_test;/home/builder/kbuilder/x64/sdk/openwrt-sdk-25.12.6-x86-64_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-x86_64_musl/zlib-1.3.1/CMakeLists.txt;0;")
add_test(example64 "example64")
set_tests_properties(example64 PROPERTIES  _BACKTRACE_TRIPLES "/home/builder/kbuilder/x64/sdk/openwrt-sdk-25.12.6-x86-64_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-x86_64_musl/zlib-1.3.1/CMakeLists.txt;245;add_test;/home/builder/kbuilder/x64/sdk/openwrt-sdk-25.12.6-x86-64_gcc-14.3.0_musl.Linux-x86_64/build_dir/target-x86_64_musl/zlib-1.3.1/CMakeLists.txt;0;")
