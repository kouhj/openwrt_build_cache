/*
 * Copyright (C) 2020-2021 Jo-Philipp Wich <jo@mein.io>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef UCODE_VM_H
#define UCODE_VM_H

#include <stdbool.h>
#include <stdarg.h>

#include <ucode/util.h>
#include <ucode/types.h>
#include <ucode/compiler.h>
#include <ucode/program.h>

typedef enum {
	STATUS_OK,
	STATUS_EXIT,
	STATUS_BREAK,
	ERROR_COMPILE,
	ERROR_RUNTIME
} uc_vm_status_t;

typedef enum {
	UC_GC_ENABLED = (1 << 0)
} uc_vm_gc_flags_t;

#define UC_GC_DEFAULT_INTERVAL 1000

/* Deprecated bare aliases -- prefer the UC_-prefixed names above. */
#define GC_ENABLED UC_GC_ENABLED
#define GC_DEFAULT_INTERVAL UC_GC_DEFAULT_INTERVAL

void uc_vm_init(uc_vm_t *vm, uc_parse_config_t *config);
void uc_vm_free(uc_vm_t *vm);

uc_value_t *uc_vm_scope_get(uc_vm_t *vm);
void uc_vm_scope_set(uc_vm_t *vm, uc_value_t *ctx);

bool uc_vm_registry_exists(uc_vm_t *vm, const char *key);
uc_value_t *uc_vm_registry_get(uc_vm_t *vm, const char *key);
void uc_vm_registry_set(uc_vm_t *vm, const char *key, uc_value_t *value);
bool uc_vm_registry_delete(uc_vm_t *vm, const char *key);

void uc_vm_stack_push(uc_vm_t *vm, uc_value_t *value);
uc_value_t *uc_vm_stack_pop(uc_vm_t *vm);
uc_value_t *uc_vm_stack_peek(uc_vm_t *vm, size_t offset);

uc_exception_handler_t *uc_vm_exception_handler_get(uc_vm_t *vm);
void uc_vm_exception_handler_set(uc_vm_t *vm, uc_exception_handler_t *exhandler);

uint32_t uc_vm_trace_get(uc_vm_t *vm);
void uc_vm_trace_set(uc_vm_t *vm, uint32_t level);

bool uc_vm_gc_start(uc_vm_t *vm, uint16_t interval);
bool uc_vm_gc_stop(uc_vm_t *vm);

uc_exception_type_t uc_vm_call(uc_vm_t *vm, bool mcall, size_t nargs);

void __attribute__((format(printf, 3, 0)))
uc_vm_raise_exception(uc_vm_t *vm, uc_exception_type_t type, const char *fmt, ...);
uc_value_t *uc_vm_exception_object(uc_vm_t *vm);

uc_vm_status_t uc_vm_execute(uc_vm_t *vm, uc_program_t *fn, uc_value_t **retval);
uc_value_t *uc_vm_invoke(uc_vm_t *vm, const char *fname, size_t nargs, ...);

uc_exception_type_t uc_vm_signal_dispatch(uc_vm_t *vm);
void uc_vm_signal_raise(uc_vm_t *vm, int signo);
int uc_vm_signal_notifyfd(uc_vm_t *vm);

/* Lazily wire up the self-pipe/handler array needed for the signal()
 * builtin to work, independent of whether the embedding host opted into
 * this via uc_parse_config_t.setup_signal_handlers. Without this, a VM
 * initialized with that flag left unset (e.g. uc_vm_init(vm, NULL)) would
 * silently install a NULL/SIG_DFL signal disposition the first time
 * script code calls signal() with a callable handler - terminating the
 * process on the next occurrence of that signal instead of invoking the
 * handler. Call this before relying on signal() from C code that doesn't
 * control how the VM was initialized (see lib/debug.c). Safe to call more
 * than once. */
void uc_vm_signal_handlers_ensure(uc_vm_t *vm);

bool uc_vm_break_requested(uc_vm_t *vm);
void uc_vm_break_request(uc_vm_t *vm);
int uc_vm_break_notifyfd(uc_vm_t *vm);
void uc_vm_break_init(uc_vm_t *vm);
void uc_vm_break_cleanup(uc_vm_t *vm);

uc_vm_status_t uc_vm_resume(uc_vm_t *vm);

/* Well-known sentinel `uc_breakpoint_t.ip` value identifying the dedicated
 * "break on uncaught exception" system breakpoint. Not a real bytecode
 * address - install a breakpoint with this as its `ip` (and any `cb`) to
 * have it invoked, with callframes fully intact, right before an exception
 * that nothing would catch starts unwinding the stack. See the comment on
 * uc_vm_exception_would_be_caught() in vm.c for the exact semantics. */
extern uint8_t *const UC_BREAKPOINT_UNCAUGHT_EXCEPTION;

#endif /* UCODE_VM_H */
